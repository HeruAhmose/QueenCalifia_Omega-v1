Write-Host "🚀 Launching QueenCalifia-Ω Full Stack..."
.env\Scriptsctivate
pip install -r requirements.txt
Start-Process powershell -ArgumentList "python main.py"
Start-Process "http://127.0.0.1:5000/dashboard"