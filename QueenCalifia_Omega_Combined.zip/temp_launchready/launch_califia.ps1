# launch_califia.ps1

# Step 1: Activate venv or create if missing
if (Test-Path ".\venv\Scripts\activate.ps1") {
    .\venv\Scripts\activate.ps1
} else {
    python -m venv venv
    .\venv\Scripts\activate.ps1
}

# Step 2: Install required packages
pip install -r requirements.txt

# Step 3: Launch Flask backend
python main.py
